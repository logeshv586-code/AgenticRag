# OmniRAG Exported Project: psg_e2e_test

This ZIP contains the complete source code for your deployed RAG system, including the full backend and the React chatbot UI (with the 3D robot).

## How to run the Backend
1. cd backend
2. pip install -r requirements.txt
3. python main.py
(The backend runs on http://localhost:8010)

## How to run the Frontend Chatbot UI
1. cd chatbotui
2. npm install
3. npm run dev
(The frontend will start and connect to your backend)

Enjoy your fully autonomous Neural Assistant!
